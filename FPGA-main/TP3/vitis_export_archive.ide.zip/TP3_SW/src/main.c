#include "my_led.h"
#include "xil_io.h"
#include "xparameters.h"

int main() {

	int sw;

	while(1) {
		sw = MY_LED_mReadReg(XPAR_GPIO_0_BASEADDR, 0); //ou XPAR_SW_BASEADDR

		if (sw == 0x1){
			MY_LED_mWriteReg(XPAR_GPIO_0_BASEADDR, MY_LED_S00_AXI_SLV_REG0_OFFSET, sw);
		}
		else if (sw == 0x2){
			MY_LED_mWriteReg(XPAR_GPIO_0_BASEADDR, MY_LED_S00_AXI_SLV_REG1_OFFSET, sw);
		}
		else if (sw == 0x4){
			MY_LED_mWriteReg(XPAR_GPIO_0_BASEADDR, MY_LED_S00_AXI_SLV_REG2_OFFSET, sw);
		}
		else if (sw == 0x8){
			MY_LED_mWriteReg(XPAR_GPIO_0_BASEADDR, MY_LED_S00_AXI_SLV_REG3_OFFSET, sw);
		}
	}

	// maybe XPAR_MY_LED_0_S00_AXI_BASEADDR

	return 0;
}
